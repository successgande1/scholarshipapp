setTimeout(function(){
    $('#message').fadeOut('slow');
}, 3000);

