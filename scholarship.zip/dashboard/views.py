from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from datetime import datetime
import datetime
from django.contrib.auth.models import User
from django.contrib import messages

from user.models import Profile, Submitted

# Create your views here.
@login_required(login_url='user-login')
def index(request):
    
    #Grab the logged in user
    user = request.user 
    #Check if user was authenticated 
    if user.is_authenticated:
        try:
            #Try to get the profile of the logged in user
            profile = Profile.objects.get(applicant=user) 
        except Profile.DoesNotExist:
            #Unless it does not exist then throw Error and redirect
            messages.error(request, 'Profile DOES NOT EXIST!')
            # Redirect to a Profile creating page?
            return redirect('user-register')
        else:
            #Check if the logged in user profile surname field is not yet Updated
            if profile.surname == None:
                #Redirect user to update his/her profile information
                return redirect('user-profile-update')
            else:
                #Redirect user to view his profile information
                return redirect('user-profile')
    
    context = {
        
    }
    return render(request, 'dashboard/index.html')
    

  