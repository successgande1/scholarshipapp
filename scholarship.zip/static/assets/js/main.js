setTimeout(function(){
    $('#message').fadeOut('slow');
}, 3000);

const form = document.getElementById('pay');

form.addEventListener("submit", payment);

function payment(e){
    //Prevent default form submission
    e.preventDefault();

    //set configurations
    FlutterwaveCheckout({
        public_key : "FLWPUBK-fe87eccf0fe3aa4bfcee68205fe4115b-X",
        tx_ref: "WASU"+Math.floor((Math.random()*1000000000)+1),
        amount: document.getElementById("amount").value,
        currency: "USD",
        customer :{

            email : document.getElementById("email").value,
            phone: document.getElementById("phone").value,
            name: document.getElementById("name").value,

        },

        callback : function(data){
            console.log(data)
        }

    }); 

}